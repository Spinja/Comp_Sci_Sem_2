import pkg.*;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import javax.swing.*;

public class starter implements InputControl, InputKeyControl {
	public static Rectangle pc;
	public static double pcy;
	public static boolean go;
	public static Rectangle start;
	public static Text begin;
	public static Rectangle screen;
	public static Rectangle goal;
	public static Rectangle p1;
	public static Rectangle grass;
	public static int level = 0;
	public static ArrayList<Rectangle> pforms = new ArrayList<Rectangle>();
	public static Rectangle spike;
	public static ArrayList<Rectangle> obstacles = new ArrayList<Rectangle>();
	public static void main(String args[]) {
		// please leave following line alone, necessary for keyboard/mouse input
		KeyController kC = new KeyController(Canvas.getInstance(),new starter());
		MouseController mC = new MouseController(Canvas.getInstance(),new starter());

		go = false;

		levelOne();

		pc = new Rectangle(10.0, 300.0, 50.0, 80.0);
		pc.draw();
		System.out.println(grounded(pc));
		
		screen = new Rectangle(0.0, 0.0, 1200.0, 800.0);
		screen.draw();
		screen.fill();
		start = new Rectangle(550.0, 250.0, 150.0, 30.0);
		start.setColor(Color.RED);
		start.draw();
		start.fill();
		begin = new Text(605.0, 255.0, "START");
		begin.draw();
	}

	public void onMouseClick(double x, double y) {
		if(x > 550.0 && x < 700.0 && y < 310.0 && y > 280.0 && !go){
			start.undraw();
			begin.undraw();
			screen.undraw();
			go = true;
		}


		System.out.println(x + " " + y);
	}

	public void keyPress(String s) {
		if(go){
			char space = (char)32;
			String spaced = Character.toString(space);
			/*if(s.equals("w")){
				pc.translate(5.0, 0.0);
			}*/
			if(s.equals("a") && !hitLeftWall(pc)){
				if(grounded(pc)){
					pc.translate(-10.0, 0.0);
				}
				else{
					pc.translate(-20.0, 130.0);
				}
				System.out.println(pc.getX() + " " + pc.getY());
			}
			else if(s.equals(spaced) && grounded(pc) && pc.getY() > 130.0){
				pc.translate(0.0, -130.0);
				System.out.println(pc.getX() + " " + pc.getY());
				/*System.out.println("H");
				try {
					Thread.sleep(200);
				}
				catch(InterruptedException ex) {
					Thread.currentThread().interrupt();
				}
				System.out.println("H");
				while(!grounded(pc)){
					pc.translate(0.0, 10.0);
				}*/
			}
			else if(s.equals("d") && !hitRightWall(pc)){
				if(grounded(pc)){
					pc.translate(10.0, 0.0);
				}
				else{
					pc.translate(20.0, 130.0);
				}
				System.out.println(pc.getX() + " " + pc.getY());
			}
			if(level == 2 && hitSpike()){
				pc.translate(-pc.getX() + 10.0, 0.0);
			}
			if(goalReached()){
				goal.undraw();
				if(level == 1){
					levelTwo();
				}
				else if(level == 2){
					levelThree();
				}
			}
		}
	}

	public static boolean grounded(Rectangle r){
		if(r.getY() == grass.getY() - 80.0){
			return true;
		}
		else if(r.getY() == pforms.get(0).getY() - 80.0 && r.getX() >= pforms.get(0).getX() - 40.0 && r.getX() <= pforms.get(0).getX() + 150.0){
			return true;
		}
		else if(r.getY() == pforms.get(1).getY() - 80.0 && r.getX() >= pforms.get(1).getX() - 40.0 && r.getX() <= pforms.get(1).getX() + 150.0){
			return true;
		}
		else if(pforms.size() >= 3 && r.getY() == pforms.get(2).getY() - 80.0 && r.getX() >= pforms.get(2).getX() - 40.0 && r.getX() <= pforms.get(2).getX() + 150.0){
			return true;
		}
		else if(pforms.size() >= 4 && r.getY() == pforms.get(3).getY() - 80.0 && r.getX() >= pforms.get(3).getX() - 40.0 && r.getX() <= pforms.get(3).getX() + 150.0){
			return true;
		}
		return false;
	}

	public static boolean hitLeftWall(Rectangle r){
		if(r.getX() <= 0.0){
			return true;
		}
		return false;
	}

	public static boolean hitRightWall(Rectangle r){
		if(r.getX() >= 1150.0){
			return true;
		}
		return false;
	}

	public static void makePlatform(double x, double y){
		p1 = new Rectangle(x, y, 160.0, 30.0);
		Color skyblue = new Color(135, 206, 235);
		p1.setColor(skyblue);
		p1.draw();
		p1.fill();
		pforms.add(p1);
	}

	public static void makePlatform(double x, double y, double w, double h, Color c){
		p1 = new Rectangle(x, y, w, h);
		p1.setColor(c);
		p1.draw();
		p1.fill();
		pforms.add(p1);
	}

	public static void makeGoal(double x, double y){
		goal = new Rectangle(x, y, 20.0, 20.0);
		goal.setColor(Color.RED);
		goal.draw();
		goal.fill();
	}

	public static boolean goalReached(){
		if(goal.contains(pc)){
			return true;
		}
		return false;
	}

	public static void makeSpike(double x, double y){
		spike = new Rectangle(x, y, 10.0, 60.0);
		spike.setColor(Color.ORANGE);
		spike.draw();
		spike.fill();
		obstacles.add(spike);
	}

	public static boolean hitSpike(){
		if(obstacles.get(0).contains(pc)){
			return true;
		}
		return false;
	}

	public static void levelOne(){
		grass = new Rectangle(0.0, 380.0, 1200.0, 500.0);
		grass.setColor(Color.GREEN);
		grass.draw();
		grass.fill();

		makePlatform(300.0, 250.0);

		makePlatform(440.0, 120.0);

		makeGoal(550.0, 100.0);

		level = 1;
	}

	public static void levelTwo(){
		grass.translate(0.0, 40.0);
		pc.translate(-pc.getX() + 10.0, 300.0);
		pforms.get(0).undraw();
		pforms.get(1).undraw();
		pforms.remove(0);
		pforms.remove(0);
		makePlatform(400.0, 290.0);
		makePlatform(550.0, 160.0);
		makePlatform(760.0, 290.0);
		makePlatform(910.0, 160.0);
		makeGoal(1040.0, 140.0);
		makeSpike(750.0, 360.0);
		level = 2;
	}

	public static void levelThree(){
		grass.translate(0.0, 40.0);
		pc.translate(-pc.getX() + 10.0, 300.0);
		pforms.get(0).undraw();
		pforms.get(1).undraw();
		pforms.get(2).undraw();
		pforms.get(3).undraw();
		obstacles.get(0).undraw();
		pforms.remove(0);
		pforms.remove(1);
		pforms.remove(2);
		pforms.remove(3);
		obstacles.remove(0);
		level = 3;
	}
}
