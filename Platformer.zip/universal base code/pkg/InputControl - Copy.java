package pkg;

public interface Player{
    public void onMouseClick(double x, double y);
}