package pkg;

public class Player{
    private static int Grav = 10;
    private static int termVeloc = 300;
    private int vertical_speed = 0;
    private double vertical_position;
    private double horizontal_position;
    private double height;
    private Rectangle p;

    public Player(){
        vertical_position = 300.0;
        horizontal_position = 10.0;
        height = 80.0;
        p = new Rectangle(horizontal_position, vertical_position, 50.0, height);
        p.draw();
    }

    public void fall ()
    {
        this.vertical_speed = this.vertical_speed + Grav;
        if (this.vertical_speed > termVeloc)
        {
            this.vertical_speed = termVeloc;
        }
        this.vertical_position = this.vertical_position - this.vertical_speed;
        p.draw();
    }

    public double getY(){
        return vertical_position;
    }

    public double getX(){
        return horizontal_position;
    }

    public double getHeight(){
        return height;
    }
}